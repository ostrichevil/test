package demo.RanTest20180130.firstWork;


/**
 * li
 * s = "abc", t = "ahbgdc"  Return true.
 * s = "axc", t = "ahbgdc"  Return false.
 */
public class isSubsequence {

    public boolean isSubsequence(String s, String t) {
        boolean isSeq = true;
        int indexs=0;
        int indext=0;
        for (int i = indexs; i < t.length(); i++) {
            for (int j = indext; j < s.length(); j++) {
                if (t.charAt(i) == s.charAt(j)) {
                    indexs++;
                    indext++;
                    continue;
                } else {
                    isSeq = false;
                }
            }
        }
        return isSeq;
    }
}
