package demo.RanTest20180130.firstWork;


/**
 * 给定一个数
 * 按字典排序给出列表
 * 思路：我的死办法想不出来
 * */
public class LexicographicalNumber {

}
